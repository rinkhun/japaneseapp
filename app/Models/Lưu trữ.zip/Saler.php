<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Saler extends Model
{
    use HasFactory;

    public $fillable = [
        'first_name',
        'last_name',
        'entry_date',
        'qrcode',
        'birthday',
        'email',
        'password',
    ];

    protected $cats = [
        'id' => 'integer',
        'first_name' => 'string',
        'last_name' => 'string',
        'entry_date'=>'date',
        'qrcode'=>'string',
        'birthday'=>'date',
        'email'=>'string',
        'password'=>'string',
    ];
}
