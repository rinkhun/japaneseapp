<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Book extends Model
{
    use HasFactory;

    protected $table = "books";

    public $fillable = [
        'name',
        'img',
    ];

    protected $cats = [
        'id'=>'integer',
        'name'=>'string',
        'img'=>'string',
    ];
}
