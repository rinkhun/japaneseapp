<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Exercise extends Model
{
    use HasFactory;


    public $fillable = [
        'title',
        'description',
        'lesson_id',
    ];

    protected $cats = [
        'id'=>'integer',
        'title'=>'string',
        'description'=>'text',
        'lesson_id'=>'integer',
    ];
}
