<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class history extends Model
{
    use HasFactory;

    public $fillable = [
        'leeson_id',
        'user_id',
        'sel_content',
    ];

    protected $cats = [
        'id' => 'integer',
        'leeson_id' => 'integer',
        'user_id' => 'integer',
        'sel_content' => 'string',
    ];
}
