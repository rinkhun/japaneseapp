<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Kanji extends Model
{
    use HasFactory;

    public $fillable = [
        'img',
        'kanji',
        'onyomi',
        'kunyomi',
        'hanviet',
        'description',
        'lesson_id',
    ];

    protected $cats = [
        'id' => 'integer',
        'img' => 'string',
        'kanji' => 'string',
        'onyomi' => 'string',
        'kunyomi'=>'string',
        'hanviet'=>'string',
        'description'=>'text',
    ];  
}
