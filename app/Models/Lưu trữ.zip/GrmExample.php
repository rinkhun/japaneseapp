<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GrmExample extends Model
{
    use HasFactory;

    public $fillable = [
        'japanese',
        'vietnamese',
        'grammar_id',
    ];

    protected $cats = [
        'id' => 'integer',
        'japanese' => 'string',
        'vietnamese' => 'string',
        'grammar_id' => 'index',
    ];
}
