<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class KnjExample extends Model
{
    use HasFactory;
    
    public $fillable = [
        'kanji',
        'hiragana',
        'mean',
        'kanji_id',
    ];

    protected $cats = [
        'id' => 'integer',
        'img' => 'string',
        'kanji' => 'string',
        'onyomi' => 'string',
        'kunyomi'=>'string',
        'hanviet'=>'string',
        'description'=>'text',
    ];  
}
